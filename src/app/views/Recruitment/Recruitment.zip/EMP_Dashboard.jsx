import React, { useRef, useState, useEffect, forwardRef } from 'react'
import Dialog from '@mui/material/Dialog'
import AppBar from '@mui/material/AppBar'
import Toolbar from '@mui/material/Toolbar'
import ReactToPrint, { PrintContextConsumer } from 'react-to-print'
import Slide from '@mui/material/Slide'
import CloseIcon from '@mui/icons-material/Close'
import { H4 } from 'app/components/Typography'
//
import {
    Card,
    Fab,
    Grid,
    styled,
    Button,
    useTheme,
    IconButton,
} from '@mui/material'
import { useNavigate } from 'react-router-dom'
import { useSelector } from 'react-redux'
import ip from '../DB/IP_Address'
//
import {
    Box,
    TableBody,
    Table,
    TableCell,
    TableHead,
    TableRow,
} from '@mui/material'
import axios from 'axios'
import EMP_Details from './EMP_Details'

const ContentBox = styled('div')(() => ({
    display: 'flex',
    flexWrap: 'wrap',
    alignItems: 'center',
}))

const CardHeader = styled(Box)(() => ({
    display: 'flex',
    paddingLeft: '24px',
    paddingRight: '24px',
    marginBottom: '12px',
    alignItems: 'center',
    justifyContent: 'space-between',
}))

const StyledButton = styled(Button)(({ theme }) => ({
    margin: theme.spacing(1),
}))

const Title = styled('span')(() => ({
    fontSize: '1rem',
    fontWeight: '500',
    textTransform: 'capitalize',
}))

const ProductTable = styled(Table)(() => ({
    minWidth: 400,
    whiteSpace: 'pre',
    '& small': {
        width: 50,
        height: 15,
        borderRadius: 500,
        boxShadow:
            '0 0 2px 0 rgba(0, 0, 0, 0.12), 0 2px 2px 0 rgba(0, 0, 0, 0.24)',
    },
    '& td': { borderBottom: 'none' },
    '& td:first-of-type': { paddingLeft: '16px !important' },
}))

const Small = styled('small')(({ bgcolor }) => ({
    width: 50,
    height: 15,
    color: '#fff',
    padding: '4px 8px',
    borderRadius: '4px',
    overflow: 'hidden',
    background: bgcolor,
    boxShadow: '0 0 2px 0 rgba(0, 0, 0, 0.12), 0 2px 2px 0 rgba(0, 0, 0, 0.24)',
}))

const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="up" ref={ref} {...props} />
})

const StatCards2 = () => {
    const ref = useRef()
    //

    //
    const { palette } = useTheme()
    const bgError = palette.error.main
    const bgSuccess = palette.success.main
    //
    const userData = useSelector((data) => data.loginReducer.LoginData)

    //
    const [DashData, setDashData] = useState([{}])
    const [openModal, setOpenModal] = useState(false)
    const [UniqueID_Details, setUniqueID_Details] = useState([])
    //
    const theme = useTheme()
    //
    function handleClose() {
        setOpenModal(false)
    }

    const navigate = useNavigate()
    useEffect(() => {
        GETALL_DASHBOARD()
    }, [])

    const GETALL_DASHBOARD = () => {
        axios
            .get(ip.localhost + 'EMP_INSERT/EMP_listbyID/' + userData._id)
            .then((response) => {
                setDashData(response.data)
            })
            .catch(function (error) {
                console.log(error)
            })
    }
    //
    const GET_DETAILS_BY_UNIQUE_ID = (id) => {
        axios
            .get(ip.localhost + 'EMP_INSERT/EMP_listby_UniqueID/' + id)
            .then((response) => {
                setUniqueID_Details(response.data)
                setOpenModal(true)
            })
            .catch(function (error) {
                console.log(error)
            })
    }
    //
    const ComponentToPrint = forwardRef((props, ref) => {
        return (
            <div ref={ref}>
                <EMP_Details DetailsData={UniqueID_Details} />
            </div>
        )
    })

    return (
        <div style={{ margin: 20 }}>
            <Grid container spacing={3} sx={{ mb: 3 }}>
                <Grid item xs={12} md={4}>
                    <Card elevation={3} sx={{ p: 2 }}>
                        <ContentBox>
                            <StyledButton
                                sx={{
                                    width: '100%',
                                    height: '50px',
                                    fontWeight: 'bold',
                                    letterSpacing: '8px',
                                }}
                                variant="contained"
                                color="primary"
                                // onClick={() =>
                                //     navigate('/dashboard/shared/Instructions')
                                // }
                            >
                                INSTRUCTIONS
                            </StyledButton>
                        </ContentBox>
                    </Card>
                </Grid>

                <Grid item xs={12} md={4}>
                    <Card elevation={3} sx={{ p: 2 }}>
                        <ContentBox>
                            <StyledButton
                                sx={{
                                    width: '100%',
                                    height: '50px',
                                    fontWeight: 'bold',
                                    letterSpacing: '8px',
                                }}
                                variant="contained"
                                color="warning"
                                // onClick={handleOpen}
                            >
                                HOW TO APPLY
                            </StyledButton>
                        </ContentBox>
                    </Card>
                </Grid>

                <Grid item xs={12} md={4}>
                    <Card elevation={3} sx={{ p: 2 }}>
                        <ContentBox>
                            <StyledButton
                                sx={{
                                    width: '100%',
                                    height: '50px',
                                    fontWeight: 'bold',
                                    letterSpacing: '8px',
                                }}
                                variant="contained"
                                color="success"
                                onClick={() => navigate('/Admission/EMP_Apply')}
                            >
                                APPLY ONLINE
                            </StyledButton>
                        </ContentBox>
                    </Card>
                </Grid>
            </Grid>

            {/*  */}

            <Card elevation={3} sx={{ pt: '20px', mb: 3 }}>
                <CardHeader>
                    <Title>Record List</Title>
                </CardHeader>

                <Box width="100%">
                    <ProductTable>
                        <TableHead>
                            <TableRow>
                                <TableCell
                                    sx={{
                                        width: '1.8%',
                                    }}
                                ></TableCell>
                                <TableCell
                                    sx={{
                                        width: '13%',
                                    }}
                                >
                                    View Details
                                </TableCell>
                                <TableCell
                                    sx={{
                                        width: '10%',
                                    }}
                                >
                                    Form ID
                                </TableCell>
                                <TableCell
                                    sx={{
                                        width: '18%',
                                    }}
                                >
                                    Employee Name
                                </TableCell>
                                <TableCell
                                    sx={{
                                        width: '15%',
                                    }}
                                >
                                    Father Name
                                </TableCell>
                                <TableCell
                                    sx={{
                                        width: '10%',
                                    }}
                                >
                                    Contact
                                </TableCell>
                                <TableCell
                                    sx={{
                                        width: '13%',
                                    }}
                                >
                                    CNIC
                                </TableCell>
                                <TableCell
                                    sx={{
                                        width: '7%',
                                    }}
                                >
                                    Status
                                </TableCell>
                                <TableCell
                                    sx={{
                                        width: '15%',
                                    }}
                                >
                                    Approval
                                </TableCell>
                            </TableRow>
                        </TableHead>

                        <TableBody>
                            {DashData?.map((product, index) => (
                                <TableRow key={index} hover>
                                    <TableCell
                                        align="left"
                                        sx={{
                                            textTransform: 'capitalize',
                                        }}
                                    ></TableCell>
                                    <TableCell
                                        align="left"
                                        onClick={() => {
                                            GET_DETAILS_BY_UNIQUE_ID(
                                                product._id
                                            )
                                        }}
                                    >
                                        <Small
                                            bgcolor={bgSuccess}
                                            style={{
                                                cursor: 'pointer',
                                                borderRadius: '5px',
                                                fontSize: '14px',
                                                width: '100%',
                                                fontWeight: 'bold',
                                            }}
                                        >
                                            View Details
                                        </Small>
                                    </TableCell>
                                    <TableCell
                                        align="left"
                                        sx={{
                                            textTransform: 'capitalize',
                                        }}
                                    >
                                        {product.EmpID}
                                    </TableCell>

                                    <TableCell
                                        align="left"
                                        sx={{
                                            textTransform: 'capitalize',
                                        }}
                                    >
                                        {product.name}
                                    </TableCell>

                                    <TableCell
                                        align="left"
                                        sx={{
                                            textTransform: 'capitalize',
                                        }}
                                    >
                                        {product.fname}
                                    </TableCell>
                                    <TableCell
                                        align="left"
                                        sx={{
                                            textTransform: 'capitalize',
                                        }}
                                    >
                                        {product.contact}
                                    </TableCell>
                                    <TableCell
                                        align="left"
                                        sx={{
                                            textTransform: 'capitalize',
                                        }}
                                    >
                                        {product.cnic}
                                    </TableCell>

                                    <TableCell align="left">
                                        <Small
                                            bgcolor={bgSuccess}
                                            style={{
                                                cursor: 'not-allowed',
                                                borderRadius: '5px',
                                                fontSize: '14px',
                                                width: '100%',
                                                fontWeight: 'bold',
                                            }}
                                        >
                                            Active
                                        </Small>
                                    </TableCell>

                                    <TableCell align="left">
                                        <Small
                                            bgcolor={
                                                product.isApprove === 0
                                                    ? bgError
                                                    : bgSuccess
                                            }
                                            style={{
                                                cursor: 'not-allowed',
                                                borderRadius: '5px',
                                                fontSize: '14px',
                                                width: '100%',
                                                fontWeight: 'bold',
                                            }}
                                        >
                                            {product.isApprove === 0
                                                ? 'Pending'
                                                : 'Approved'}
                                        </Small>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </ProductTable>
                </Box>
            </Card>
            <Dialog
                fullScreen
                open={openModal}
                onClose={handleClose}
                TransitionComponent={Transition}
            >
                <AppBar
                    sx={{ position: 'relative' }}
                    style={{ background: '#323639' }}
                >
                    <Toolbar>
                        <IconButton
                            edge="start"
                            color="inherit"
                            onClick={handleClose}
                            aria-label="Close"
                        >
                            <CloseIcon />
                        </IconButton>

                        {/* <img src={companyLogo}></img> */}
                        <H4
                            sx={{
                                flex: 1,
                                marginLeft: theme.spacing(2),
                            }}
                        >
                            Application Details
                        </H4>
                        {/* PRINT */}

                        <ReactToPrint content={() => ref.current}>
                            <PrintContextConsumer>
                                {({ handlePrint }) => (
                                    <div
                                        style={{
                                            textAlign: 'right',
                                        }}
                                    >
                                        <StyledButton
                                            onClick={handlePrint}
                                            type="submit"
                                            variant="contained"
                                            color="error"
                                            sx={{
                                                letterSpacing: '5px',
                                                fontWeight: 'bolder',
                                            }}
                                        >
                                            PRINT
                                        </StyledButton>
                                    </div>
                                )}
                            </PrintContextConsumer>
                        </ReactToPrint>
                    </Toolbar>
                </AppBar>

                <Box width="100%" overflow="auto">
                    <div>
                        <div id="divToPrint">
                            <ComponentToPrint ref={ref} />
                        </div>
                    </div>
                </Box>
            </Dialog>
        </div>
    )
}

export default StatCards2
